﻿using System;

namespace WindowsFormsApp1
{
    internal class DatabaseManager : IDisposable
    {
        internal IDisposable GetConnection()
        {
            throw new NotImplementedException();
        }
    }
}