﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MinecraftManager.Utils;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData(); // Cargar datos al iniciar el formulario
        }

        private void LoadData()
        {
            using (var dbManager = new DatabaseManager())
            {
                using (var connection = dbManager.GetConnection())
                {
                    try
                    {
                        connection.Open();
                        var query = "SELECT Id, Nombre, Nivel, FechaCreacion FROM Jugadores";
                        var command = new SqlCommand(query, connection);
                        var adapter = new SqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dgvInventory.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al cargar datos: {ex.Message}");
                    }
                }
            }
        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPlayerName.Text))
            {
                MessageBox.Show("Por favor, ingresa un nombre de jugador.");
                return;
            }

            using (var dbManager = new DatabaseManager())
            {
                using (var connection = dbManager.GetConnection())
                {
                    try
                    {
                        connection.Open();
                        var query = "INSERT INTO Jugadores (Nombre, Nivel, FechaCreacion) VALUES (@Nombre, @Nivel, @FechaCreacion)";
                        var command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Nombre", txtPlayerName.Text);
                        command.Parameters.AddWithValue("@Nivel", 1); // Nivel inicial
                        command.Parameters.AddWithValue("@FechaCreacion", DateTime.Now);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Jugador agregado correctamente.");
                        LoadData(); // Recargar los datos
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al agregar jugador: {ex.Message}");
                    }
                }
            }
        }

        private void btnDeletePlayer_Click(object sender, EventArgs e)
        {
            if (dgvInventory.SelectedRows.Count > 0)
            {
                var selectedRow = dgvInventory.SelectedRows[0];
                var jugadorId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                using (var dbManager = new DatabaseManager())
                {
                    using (var connection = dbManager.GetConnection())
                    {
                        try
                        {
                            connection.Open();
                            var query = "DELETE FROM Jugadores WHERE Id = @Id";
                            var command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@Id", jugadorId);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Jugador eliminado correctamente.");
                            LoadData(); // Recargar los datos
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al eliminar jugador: {ex.Message}");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un jugador para eliminar.");
            }
        }

        private void btnUpdatePlayer_Click(object sender, EventArgs e)
        {
            if (dgvInventory.SelectedRows.Count > 0)
            {
                var selectedRow = dgvInventory.SelectedRows[0];
                var jugadorId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                if (string.IsNullOrWhiteSpace(txtPlayerName.Text))
                {
                    MessageBox.Show("Por favor, ingresa un nuevo nombre para el jugador.");
                    return;
                }

                using (var dbManager = new DatabaseManager())
                {
                    using (var connection = dbManager.GetConnection())
                    {
                        try
                        {
                            connection.Open();
                            var query = "UPDATE Jugadores SET Nombre = @Nombre WHERE Id = @Id";
                            var command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@Nombre", txtPlayerName.Text);
                            command.Parameters.AddWithValue("@Id", jugadorId);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Jugador modificado correctamente.");
                            LoadData(); // Recargar los datos
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al modificar jugador: {ex.Message}");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un jugador para modificar.");
            }
        }
    }
}
